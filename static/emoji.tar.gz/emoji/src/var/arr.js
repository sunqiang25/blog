define( function() {
    return [];
} );