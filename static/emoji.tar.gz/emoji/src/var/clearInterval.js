define([], function() {
    return window.clearInterval;
});