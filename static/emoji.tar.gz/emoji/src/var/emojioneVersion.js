define([], function() {
    return window.emojioneVersion || '1.5.2';
});