# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import User


class Comment(models.Model):
    name = models.ForeignKey(User,related_name='user_comments',null=True,blank=True,on_delete=models.SET_NULL,default=None)
    email = models.EmailField(max_length=255,blank=True)
    url = models.URLField(blank=True)
    text = models.TextField()
    created_time = models.DateTimeField(auto_now_add=True)

    post = models.ForeignKey('Blog_Module.Article')

    def __unicode__(self):
        return self.text[:20]
    class Meta:
        ordering = ['-created_time']
        db_table = 'Comment'



