# -*- coding: utf-8 -*-
'''
from __future__ import unicode_literals
from account.models import User
from django import forms
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render,render_to_response
from django.shortcuts import render,render_to_response,get_object_or_404,redirect,HttpResponse
from django.contrib import auth
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth.decorators import login_required
# Create your views here.

class UserForm(forms.Form):
    username = forms.CharField(label='Username:',max_length=50)
    password = forms.CharField(label='Password:',max_length=100)
    email = forms.EmailField(label='Email')


@csrf_exempt
def register(request):
    if request.method == 'POST':
        uf = UserForm(request.POST)
        if uf.is_valid():
            username = uf.cleaned_data['username']
            password = uf.cleaned_data['password']
            email = uf.cleaned_data['email']

            user = User()
            user.username = username
            user.password = password
            user.email = email
            user.save()
            request.session['username'] = username
            #return render_to_response('success.html',{'username':username})
            #return redirect('/')
            return HttpResponse('Register Success')
    else:
        uf = UserForm()

    return render_to_response('register.html',{'uf':uf})

@csrf_exempt
def login(request):
    context = {}
    if request.method == 'POST':
        uf = UserForm(request.POST)
        if uf.is_valid():
            print 'yse'
            username = uf.cleaned_data['username']
            password = uf.cleaned_data['password']
            user = User.objects.filter(username=username,password=password)

            if user:
                request.session['username'] = username
                return redirect('/')

            else:
                context = {'isLogin':False,'pwd':False}
                return render_to_response('login.html',context=context)



    else:
        context={'isLogin':False,'pwd':True}
        return render_to_response('login.html',context=context)


def logout(request):
    request.session.flush()
    return redirect('/')

@csrf_exempt
def register(request):
    content ={}
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            emai = form.cleaned_data['email']
            #pan duan yong hu shi fou cun zai
            user = auth.authenticate(username=username,password=password)
            if user:
                content['userExist'] = True
                return render(request,'register.html',content)
            # tian jia dao shu ju ku
            user = User.objects.create_user(username=username,password=password)
            user.save()

            #tian jia dao session
            request.session['username']=username
            #diao yong auth deng lu
            auth .login(request,user)
            return redirect('/')
    else:
        content = {'isLogin':False}

    return render_to_response('register.html',content)
@csrf_exempt
def login(request):
    content = {}
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            #biao dan shu ju he shu ju ke shu ju bi jiao
            user = authenticate(username=username,password=password)
            if user:
                auth.login(request,user)
                request.session['username']=username
                return redirect('/')
            else:
                content = {'isLogin':False,'pwd':False}
                return render_to_response('login.html',content)
    else:
        content = {'isLogin': False, 'pwd': False}
    return render_to_response('login.html',content)
def logout(request):
    auth.logout(request)
    return redirect('/')


'''