from django.db.models import F
from .models import Article
from Blog import celery_app
import requests,json

@celery_app.task
def incr_readtimes(article_id):
    return Article.objects.filter(id=article_id).update(views=F('views')+1)

@celery_app.task
def incr_likes(article_id):
    return Article.objects.filter(id=article_id).update(likes=F('likes')+2)

@celery_app.task
def data(keyword):
    url = 'https://api.github.com/search/repositories?q=%s&sort=forks&order=desc&per_page=1000'%(keyword)
    All_data = requests.get(url)
    hjson = json.loads(All_data.text)
    data = hjson['items']
    language=[]
    for item in data:
        language.append(item['language'])
    set_lauguage = set(language)
    #language_list=[]
    #num_list =[]
    list={}
    for i in set_lauguage:
        list[i] = language.count(i)
        #language_list.append(i)
        #num_list.append(language.count(i))

    return list
