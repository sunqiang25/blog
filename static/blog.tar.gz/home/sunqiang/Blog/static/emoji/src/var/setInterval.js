define([], function() {
   return window.setInterval;
});