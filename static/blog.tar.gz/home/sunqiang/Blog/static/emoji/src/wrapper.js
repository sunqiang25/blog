/*!
 * EmojioneArea v@VERSION
 * https://github.com/mervick/emojionearea
 * Copyright Andrey Izman and other contributors
 * Released under the MIT license
 * Date: @DATE
 */
(function(document, window, $) {
    'use strict';

// @CODE
// build.js inserts compiled code here

}) (document, window, jQuery);